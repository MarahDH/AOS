import FormInputSaveField from "@components/FormInputSaveField";

const FormTextField = (props: any) => (
  <FormInputSaveField {...props} numeric={false} />
);

export default FormTextField;
