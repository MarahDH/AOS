export const textFields = [
  "general_offer_number",
  "general_order_number",
  "general_article_number",
  "general_tool_number",
  "general_color",
  "general_comments",
  "general_request_number",
  // CUSTOMER
  "general_customer",
  "general_customer_contact_person",
  "general_customer_article_number",

  // Raw Materials
  "supplier",

  //progress
  "runningcard_qualitity_indication",
  "runningcard_printing",
  "runningcard_packing_description",
  "runningcard_tool_hint",
];
