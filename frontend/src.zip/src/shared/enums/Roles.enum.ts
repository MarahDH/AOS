export enum Roles {
  ADMIN = "admin",
  Sales = "sales",
  PRODUCTION = "production",
}
