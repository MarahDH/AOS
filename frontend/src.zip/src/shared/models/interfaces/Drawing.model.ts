export interface Drawing {
  id: number;
  filename: string;
  upload_date: string;
  preview_url: string;
}
