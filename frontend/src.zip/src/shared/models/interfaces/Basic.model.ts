export interface BasicModel {
  id: number;
  name: string;
}
