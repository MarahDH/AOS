export interface OffersModel {
  id: number;
  general_offer_number: string;
  general_customer: string;
  general_profile_description: string;
  general_creation_date: string;
  status: string;
}
